import React from 'react';
 
function LoginForm() {
  return (
    <div>
            Login page
    </div>
  );
}

export default LoginForm;
