import React from 'react';
 
function JoinForm() {
  return (
    <div>
        Sign-up page
    </div>
  );
}

export default JoinForm;
