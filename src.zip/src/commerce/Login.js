import React, { useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import { useHistory } from 'react-router-dom'; // Import useHistory
import './Login.css';

function Login() {
  const history = useHistory(); // Initialize useHistory
  const [formData, setFormData] = useState({
    userName: '',
    password: ''
  });

  // Update formData state when input values change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted');
    console.log('FormData:', formData);
    if (formData.userName === 'user' && formData.password === '123') {
      console.log('Login successful. Redirecting to IP Records page...');
      history.push('/ip-records');
    } else {
      alert('Incorrect username or password');
    }
  };
  
  return (
    <div>
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>User Name</Form.Label>
          <Form.Control 
            type="text" 
            name="userName" // Set name attribute for username field
            value={formData.userName}
            onChange={handleChange} // Handle username change
            placeholder="User Name" 
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control 
            type="password" 
            name="password" // Set name attribute for password field
            value={formData.password}
            onChange={handleChange} // Handle password change
            placeholder="Password" 
          />
        </Form.Group>
        <Button variant="success" type="submit">
          Submit
        </Button>
      </Form>
    </div>
  );
}

export default Login;
