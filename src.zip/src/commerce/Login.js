import React from 'react';
import { Button, Form } from 'react-bootstrap';
import'./Login.css';
 
function Login() {
  return (
    <div>
       
       <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>User Name</Form.Label>
        <Form.Control type="userName" placeholder="User Name" />
        <Form.Text className="text-muted">
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Button variant="success" type="submit">
        Submit
      </Button>
    </Form>



    </div>
  );
}

export default Login;
