import React, { useState } from "react";
import { Card, Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./Admin.css";

function Admin(props) {
  // Sample data for IP information table
  const ipData = [
    {
      ipAddress: "192.168.1.1",
      ipInfo: "Some information",
      company: "Company A",
      class: "input",
      readonly: "readonly",
    },
    {
      ipAddress: "10.0.0.1",
      ipInfo: "More information",
      company: "Company B",
      class: "input",
      readonly: "readonly",
    },
    // Add more sample data as needed
  ];

  

  // Sample data for user information table
  const userData = [
    {
      username: "user1",
      password: "password1",
      userId: "1",
      appId: "app1",
      class: "input",
      readonly: "readonly",
    },
    {
      username: "user2",
      password: "password2",
      userId: "2",
      appId: "app2",
      class: "input",
      readonly: "readonly",
    },
    // Add more sample data as needed
  ];

  // State to manage IP information data
  const [ipInformation, setIpInformation] = useState(ipData);

  // State to manage user information data
  const [userInfo, setUserInfo] = useState(userData);

  // Function to handle filter button click
  const handleFilter = () => {
    // Add your filter logic here
    console.log("Filter button clicked");

    var filterValue = document.getElementById("filterInput").value;
    console.log("Filter Value:", filterValue); // Debugging line

    // Get the table and rows
    var table = document.getElementById("ipInformation");
    var tr = table.getElementsByTagName("tr");

    // Loop through all table rows
    for (var i = 1; i < tr.length; i++) {
      var td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        var input = td.querySelector("input");
        var txtValue = input ? input.value : td.textContent || td.innerText;
        console.log("Comparing:", txtValue, "with", filterValue); // Debugging line
        if (txtValue.includes(filterValue)) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  };

  // Function to handle add button click
  const handleAdd = () => {
    // Add your add logic here
    console.log("Add button clicked");

    var table = document.getElementById("ipInformation");

    // Insert a new row at the end of the table
    var newRow = table.insertRow(-1);

    // Insert cells in the row
    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);

    // Add content to the new cells
    cell1.innerHTML =
      '<input type="text" readonly="readonly" class="input" placeholder="Click Edit to Enter IP Address">';
    cell2.innerHTML =
      '<input type="text" readonly="readonly" class="input" placeholder="Click Edit to Enter IP Info">';
    cell3.innerHTML =
      '<input type="text" readonly="readonly" class="input" placeholder="Click Edit to Enter Company">';
  };

  // Function to handle edit button click
  const handleEdit = () => {
    // Add your edit logic here
    console.log("Edit button clicked");

    //get ids for the edit btn and text fields
    var textFields = document.getElementsByClassName("input");
    var editBtn = document.getElementById("Edit");

    //loop through all fields
    for (var i = 0; i < textFields.length; i++) {
      var textField = textFields[i];
      if (textField.hasAttribute("readonly")) {
        textField.removeAttribute("readonly");
        editBtn.textContent = "Save";
      } else {
        textField.setAttribute("readonly", true);
        editBtn.textContent = "Edit";
      }
    }
  };

  // Function to handle delete button click
  const handleDelete = () => {
    // Add your delete logic here
    console.log("Delete button clicked");

    var ipTable = document.getElementById("ipInformation");

    // Get the number of rows in the table
    var rowCount = ipTable.rows.length;

    // Make sure there's more than one row (excluding the header)
    if (rowCount > 1) {
      // Remove the last row
      ipTable.deleteRow(rowCount - 1);
    }
  };

  return (
    <div className="content">
      <div className="crud-container">
        <form className="crud-Form">
          <button
            type="button"
            id="Filter"
            className="filter-button"
            onClick={handleFilter}
          >
            Filter
          </button>
          <button
            type="button"
            id="Add"
            className="add-button"
            onClick={handleAdd}
          >
            Add
          </button>
          <button
            type="button"
            id="Edit"
            className="edit-button"
            onClick={handleEdit}
          >
            Edit
          </button>
          <button
            type="button"
            id="Delete"
            className="delete-button"
            onClick={handleDelete}
          >
            Delete
          </button>
        </form>
      </div>
      <div className="table-container">
        <input
          type="text"
          id="filterInput"
          placeholder="Search for IP Address..."
        ></input>
        <table id="ipInformation">
          <thead>
            <tr>
              <th>IP Address</th>
              <th>IP info</th>
              <th>Company</th>
            </tr>
          </thead>
          <tbody>
        <tr>
          <td>
            <input
              type="text"
              class="input"
              readonly="readonly"
              value="192.0.3.7"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="local ip"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="company b"
            />
          </td>
        </tr>
        <tr>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="183.3.5.1"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="mobile ip"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="company a"
            />
          </td>
        </tr>
        <tr>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="192.6.5.7"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="tablet ip"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="company b"
            />
          </td>
        </tr>
        <tr>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="186.2.5.1"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="local ip"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="company c"
            />
          </td>
        </tr>
          </tbody>
        </table>
        <table id="UserInfoTable">
          <thead>
            <tr>
              <th>Username</th>
              <th>Password</th>
              <th>User ID</th>
              <th>App ID</th>
            </tr>
          </thead>
          <tbody>
        <tr>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="username1"
            />
          </td>
          <td>
            <input
              class="input"
              type="text"
              readonly="readonly"
              value="password1"
            />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="userid1" />
          </td>

          <td>
            <input class="input" type="text" readonly="readonly" value="1" />
          </td>
        </tr>
        <tr>
          <td>
            <input class="input" type="text" readonly="readonly" value="username2" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="password2" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="userid2" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="2" />
          </td>
        </tr>
        <tr>
          <td>
            <input class="input" type="text" readonly="readonly" value="username3" />
          </td>
          <td>
            <input class="input"  type="text" readonly="readonly" value="password3" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="userid3" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="3" />
          </td>
        </tr>
        <tr>
          <td>
            <input class="input" type="text" readonly="readonly" value="username4" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="password4" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="userid4" />
          </td>
          <td>
            <input class="input" type="text" readonly="readonly" value="4" />
          </td>
        </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Admin;
