import React from 'react';
import {Card, Table} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import'./Admin.css';

function Admin(props) {


    return (
   
  
      <div class="content">
      
      <div class="crud-container">
          <form class="crud-Form">
              <button type="button" id="Filter" class="filter-button">Filter</button>
              <button type="button" id="Add" class="add-button">Add</button>
              <button type="button" id="Edit" class="edit-button">Edit</button>
              <button type="button" id="Delete" class="delete-button">Delete</button>
              
          </form>
      </div>
      <div class="table-container">
          <table id="ipInformation">
              <thead>
                  <tr>
                      <th>IP Address</th>
                      <th>IP info</th>
                      <th>Company</th>
                  </tr>
              </thead>
              <tbody>
              </tbody>
          </table>
          <table id="UserInfoTable">
              <thead>
                  <tr>
                      <th>Username</th>
                      <th>Password</th>
                      <th>User ID</th>
                      <th>App ID</th>
                  </tr>
              </thead>
              <tbody>
              </tbody>
          </table>
      </div>
  </div>
  
   
   
  
    );
  }
  
  export default Admin;