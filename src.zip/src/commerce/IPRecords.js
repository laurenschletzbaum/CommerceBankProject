import React, { useState } from 'react';
import { Card, Table, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './IPRecords.css';

function IPRecords(props) {
  // Dummy IP records data
  const [showForm, setShowForm] = useState(false);
  const [newRecord, setNewRecord] = useState({
    ipAddress: '',
    applicationId: '',
    server: '',
    port: '',
    dateModified: ''
  });

  const ipRecordsData = [
    {
      ipAddress: '192.168.0.1',
      applicationId: 'App1',
      server: 'Server1',
      port: '8080',
      dateModified: '2024-04-10',
    },
    {
      ipAddress: '192.168.0.2',
      applicationId: 'App2',
      server: 'Server2',
      port: '9090',
      dateModified: '2024-04-11',
    },
    // Add more dummy data as needed
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewRecord(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you can handle the submission of the new record
    // For demonstration purpose, I'm just logging the new record
    console.log("New Record Submitted:", newRecord);
    // Close the form
    setShowForm(false);
  };

  return (
    <div className="content">
      <div className="crud-container">
        <button 
          type="button" 
          id="addRecordBtn" 
          className="add-button" 
          onClick={() => setShowForm(true)}
        >
          Add New Record
        </button>
      </div>
      <div className="table-container">
        <table id="ipRecords" className="table">
          <thead>
            <tr>
              <th>IP Address</th>
              <th>Application ID</th>
              <th>Server</th>
              <th>Port</th>
              <th>Date Modified</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {/* Map through ipRecordsData and render rows */}
            {ipRecordsData.map((record, index) => (
              <tr key={index}>
                <td>{record.ipAddress}</td>
                <td>{record.applicationId}</td>
                <td>{record.server}</td>
                <td>{record.port}</td>
                <td>{record.dateModified}</td>
                {/* Add actions buttons if needed */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add New Record Form */}
      {showForm && (
        <div className="add-record-form">
          <h3>Add New Record</h3>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formIpAddress">
              <Form.Label>IP Address</Form.Label>
              <Form.Control 
                type="text" 
                name="ipAddress" 
                value={newRecord.ipAddress} 
                onChange={handleInputChange} 
              />
            </Form.Group>
            <Form.Group controlId="formApplicationId">
              <Form.Label>Application ID</Form.Label>
              <Form.Control 
                type="text" 
                name="applicationId" 
                value={newRecord.applicationId} 
                onChange={handleInputChange} 
              />
            </Form.Group>
            <Form.Group controlId="formServer">
              <Form.Label>Server</Form.Label>
              <Form.Control 
                type="text" 
                name="server" 
                value={newRecord.server} 
                onChange={handleInputChange} 
              />
            </Form.Group>
            <Form.Group controlId="formPort">
              <Form.Label>Port</Form.Label>
              <Form.Control 
                type="text" 
                name="port" 
                value={newRecord.port} 
                onChange={handleInputChange} 
              />
            </Form.Group>
            <Form.Group controlId="formDateModified">
              <Form.Label>Date Modified</Form.Label>
              <Form.Control 
                type="text" 
                name="dateModified" 
                value={newRecord.dateModified} 
                onChange={handleInputChange} 
              />
            </Form.Group>
            <Button variant="primary" type="submit">
              Submit
            </Button>
            <Button variant="secondary" onClick={() => setShowForm(false)}>
              Cancel
            </Button>
          </Form>
        </div>
      )}
    </div>
  );
}

export default IPRecords;
