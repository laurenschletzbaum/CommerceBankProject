import react from 'react';
import { Button, Container, Nav, Navbar } from 'react-bootstrap';
import {Link} from 'react-router-dom';

 
function Header() {
  return (
<>
  <Navbar bg="dark" variant="dark">
    <Container>
    <Link to ="/login" className = "navbar-brand">Login</Link>

    <Nav className="me-auto">
      <Link to ="/IPRecords" className = "nav-link">IP Records</Link>
      <Link to ="/SpecificIP" className = "nav-link">SpecificIP</Link>
      <Link to ="/Admin" className = "nav-link">Admin</Link>
 
    </Nav>
    </Container>
  </Navbar>
  <br />
 
 
</>
  );
}

export default Header;

